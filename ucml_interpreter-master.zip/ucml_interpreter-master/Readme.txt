Submitted By:
  -Arpan Barua
  

To build:-
$ make clean
$ make -f Makefile.prod

To run:-
$ ./uc z_variables.go
