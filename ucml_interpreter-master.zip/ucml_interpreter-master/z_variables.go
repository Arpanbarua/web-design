pi:double = 3.1415
r: int = 5

// get the circumference
2*pi*r